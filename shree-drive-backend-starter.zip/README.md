# Shree Drive Backend (Google Drive Uploader)

See chat for full instructions.
